const sql = require ('mssql');

var connSQLServer = function(){
    sqlConfig = {
    user: 'pcAdmin',
    password: 'pcKaiqueAdmin4321',
    database: 'cursos', //Na FATEC, utilizar o database BD ou LP8
    server: 'KAIQUE\\SQLEXPRESS',//Caso o nome tenha uma instância, colocar duas barras, ex: ‘DESKTOP\\SQLSERVER. Na FATEC, utilizar o ip: 192.168.1.6 no nome do servidor
    driver: 'msnodesqlv8',
        options: {
                encrypt: false,
                trustServerCertificate: true,
            }
        }
    return sql.connect(sqlConfig);
}

module.exports = function(){
    console.log('O autoload carregou o modulo de conexão');
    return connSQLServer;
}
