const sql = require ('mssql');

var connSQLServer = function(){
    sqlConfig = {
    user: 'adminPc',
    password: 'pcKaiqueAdmin4321',
    database: 'cursos', 
    server: 'KAIQUE\\SQLEXPRESS',
    driver: 'msnodesqlv8',
        options: {
                encrypt: false,
                trustServerCertificate: true,
            }
        }
    return sql.connect(sqlConfig);
}

module.exports = function(){
    console.log('O autoload carregou o modulo de conexão');
    return connSQLServer;
}
